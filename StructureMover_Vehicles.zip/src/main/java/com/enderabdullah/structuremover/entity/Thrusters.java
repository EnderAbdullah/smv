package com.enderabdullah.structuremover.entity;

import com.enderabdullah.structuremover.StructureMoverMod;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

import java.util.regex.Pattern;

/**
 * Detects "thruster" blocks (fans, propellers, bearings... for example from Create) by block tag or by name,
 * without needing Create as a compile-time dependency.
 *
 * A thruster pushes the vehicle OPPOSITE to the direction the block blows its air (its "facing").
 */
public final class Thrusters {
    public static final TagKey<Block> TAG = TagKey.create(Registries.BLOCK,
            ResourceLocation.fromNamespaceAndPath(StructureMoverMod.MOD_ID, "thrusters"));

    private static final Pattern NAME = Pattern.compile(
            "(?:^|_)(?:propeller|fan|thruster|jet|turbine|rotor)(?:_|$)|bearing");

    private Thrusters() {
    }

    public static boolean isThruster(BlockState state) {
        if (state.is(TAG)) return true;
        ResourceLocation id = BuiltInRegistries.BLOCK.getKey(state.getBlock());
        if (StructureMoverMod.MOD_ID.equals(id.getNamespace())) return false;
        return NAME.matcher(id.getPath()).find();
    }

    /** The direction the block blows air towards. */
    public static Direction airDirection(BlockState state) {
        if (state.hasProperty(BlockStateProperties.FACING)) {
            return state.getValue(BlockStateProperties.FACING);
        }
        if (state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
            return state.getValue(BlockStateProperties.HORIZONTAL_FACING);
        }
        if (state.hasProperty(BlockStateProperties.AXIS)) {
            return Direction.fromAxisAndDirection(state.getValue(BlockStateProperties.AXIS), Direction.AxisDirection.POSITIVE);
        }
        if (state.hasProperty(BlockStateProperties.HORIZONTAL_AXIS)) {
            return Direction.fromAxisAndDirection(state.getValue(BlockStateProperties.HORIZONTAL_AXIS), Direction.AxisDirection.POSITIVE);
        }
        return Direction.UP;
    }

    /** The direction the vehicle is pushed (opposite to the air). */
    public static Direction pushDirection(BlockState state) {
        return airDirection(state).getOpposite();
    }
}
