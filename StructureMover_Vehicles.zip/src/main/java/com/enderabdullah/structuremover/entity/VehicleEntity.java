package com.enderabdullah.structuremover.entity;

import com.enderabdullah.structuremover.StructureMoverMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple drivable vehicle made of blocks. It is not a rigid-body physics engine:
 * the vehicle stays level, uses gravity, vanilla block collision and a bicycle-style steering model.
 */
public class VehicleEntity extends Entity {

    /** Block data is synced to clients through vanilla synched entity data (no NeoForge-specific API needed). */
    private static final EntityDataAccessor<CompoundTag> PARTS_DATA =
            SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.COMPOUND_TAG);

    /** One block of the vehicle. The offset is relative to the vehicle origin (an integer corner). */
    public record Part(BlockPos offset, BlockState state) {
    }

    private final List<Part> parts = new ArrayList<>();
    private float baseYaw;
    private int wheelCount;
    private BlockPos seatOffset;
    private int boxSide = 1;
    private int boxHeight = 1;
    /** Thruster push directions (x, z) in the original build orientation, plus vertical thruster counts. */
    private final List<double[]> sideThrusters = new ArrayList<>();
    private int thrustUp;
    private int thrustDown;

    private double velX, velY, velZ;
    private double steer;
    private float wheelRot, wheelRotO;
    private boolean inputUp, inputDown;
    private int inputRotate;

    private int lerpSteps;
    private double lerpX, lerpY, lerpZ;
    private float lerpYaw;

    public VehicleEntity(EntityType<? extends VehicleEntity> type, Level level) {
        super(type, level);
    }

    // ---------- data ----------

    public List<Part> getBlockParts() {
        return parts;
    }

    public float getWheelRot(float partialTick) {
        return wheelRotO + (wheelRot - wheelRotO) * partialTick;
    }

    public float getBaseYaw() {
        return baseYaw;
    }

    public void setParts(List<Part> newParts, float baseYaw) {
        applyParts(newParts, baseYaw);
        if (!level().isClientSide) {
            entityData.set(PARTS_DATA, encodeParts());
        }
    }

    private void applyParts(List<Part> newParts, float baseYaw) {
        this.parts.clear();
        this.parts.addAll(newParts);
        this.baseYaw = baseYaw;
        recompute();
    }

    private CompoundTag encodeParts() {
        int[] data = new int[parts.size() * 4];
        int i = 0;
        for (Part p : parts) {
            data[i++] = p.offset().getX();
            data[i++] = p.offset().getY();
            data[i++] = p.offset().getZ();
            data[i++] = Block.getId(p.state());
        }
        CompoundTag tag = new CompoundTag();
        tag.putFloat("Yaw", baseYaw);
        tag.putIntArray("P", data);
        return tag;
    }

    private void decodeParts(CompoundTag tag) {
        int[] data = tag.getIntArray("P");
        List<Part> loaded = new ArrayList<>(data.length / 4);
        for (int i = 0; i + 3 < data.length; i += 4) {
            loaded.add(new Part(new BlockPos(data[i], data[i + 1], data[i + 2]), Block.stateById(data[i + 3])));
        }
        applyParts(loaded, tag.getFloat("Yaw"));
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> accessor) {
        super.onSyncedDataUpdated(accessor);
        if (PARTS_DATA.equals(accessor) && level().isClientSide) {
            decodeParts(entityData.get(PARTS_DATA));
        }
    }

    private void recompute() {
        wheelCount = 0;
        seatOffset = null;
        sideThrusters.clear();
        thrustUp = 0;
        thrustDown = 0;
        boolean server = !level().isClientSide;
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (Part p : parts) {
            BlockPos o = p.offset();
            if (p.state().is(StructureMoverMod.VEHICLE_WHEEL.get())) wheelCount++;
            if (seatOffset == null && p.state().is(StructureMoverMod.STEERING_WHEEL.get())) seatOffset = o;
            if (server && Thrusters.isThruster(p.state())) {
                Direction push = Thrusters.pushDirection(p.state());
                if (push == Direction.UP) thrustUp++;
                else if (push == Direction.DOWN) thrustDown++;
                else sideThrusters.add(new double[]{push.getStepX(), push.getStepZ()});
            }
            minX = Math.min(minX, o.getX());
            minY = Math.min(minY, o.getY());
            minZ = Math.min(minZ, o.getZ());
            maxX = Math.max(maxX, o.getX());
            maxY = Math.max(maxY, o.getY());
            maxZ = Math.max(maxZ, o.getZ());
        }
        if (parts.isEmpty()) {
            boxSide = 1;
            boxHeight = 1;
        } else {
            boxSide = Math.max(maxX - minX + 1, maxZ - minZ + 1);
            boxHeight = maxY - Math.min(minY, 0) + 1;
        }
        refreshDimensions();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return EntityDimensions.fixed(Math.max(1, boxSide), Math.max(1, boxHeight));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(PARTS_DATA, new CompoundTag());
    }

    // ---------- saving ----------

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putFloat("BaseYaw", baseYaw);
        ListTag list = new ListTag();
        for (Part p : parts) {
            CompoundTag t = new CompoundTag();
            t.putInt("x", p.offset().getX());
            t.putInt("y", p.offset().getY());
            t.putInt("z", p.offset().getZ());
            t.put("s", NbtUtils.writeBlockState(p.state()));
            list.add(t);
        }
        tag.put("Parts", list);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        HolderGetter<Block> blocks = level().holderLookup(Registries.BLOCK);
        ListTag list = tag.getList("Parts", Tag.TAG_COMPOUND);
        List<Part> loaded = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            BlockState state = NbtUtils.readBlockState(blocks, t.getCompound("s"));
            loaded.add(new Part(new BlockPos(t.getInt("x"), t.getInt("y"), t.getInt("z")), state));
        }
        setParts(loaded, tag.getFloat("BaseYaw"));
    }

    // ---------- behaviour ----------

    public void setInputs(boolean up, boolean down, int rotate) {
        this.inputUp = up;
        this.inputDown = down;
        this.inputRotate = Mth.clamp(rotate, -1, 1);
    }

    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public float maxUpStep() {
        return 1.0f;
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().isEmpty();
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (player.isSecondaryUseActive()) {
            if (!level().isClientSide) {
                disassemble();
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (!level().isClientSide) {
            if (player.startRiding(this)) {
                player.displayClientMessage(Component.translatable("message.structuremover.controls"), true);
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    private Vec3 seatWorld() {
        double lx = 0, ly = 0, lz = 0;
        if (seatOffset != null) {
            lx = seatOffset.getX() + 0.5;
            ly = seatOffset.getY();
            lz = seatOffset.getZ() + 0.5;
        }
        double th = Math.toRadians(getYRot() - baseYaw);
        double rx = lx * Math.cos(th) - lz * Math.sin(th);
        double rz = lx * Math.sin(th) + lz * Math.cos(th);
        return new Vec3(getX() + rx, getY() + ly, getZ() + rz);
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!hasPassenger(passenger)) return;
        Vec3 seat = seatWorld();
        callback.accept(passenger, seat.x, seat.y, seat.z);
    }

    @Override
    public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYaw = yRot;
        this.lerpSteps = Math.max(steps, 2);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (lerpSteps > 0) {
                double nx = getX() + (lerpX - getX()) / lerpSteps;
                double ny = getY() + (lerpY - getY()) / lerpSteps;
                double nz = getZ() + (lerpZ - getZ()) / lerpSteps;
                float nyaw = getYRot() + (float) Mth.wrapDegrees(lerpYaw - getYRot()) / lerpSteps;
                lerpSteps--;
                setPos(nx, ny, nz);
                setRot(nyaw, 0.0f);
            }
            double yawR = Math.toRadians(getYRot());
            double moved = (getX() - xo) * -Math.sin(yawR) + (getZ() - zo) * Math.cos(yawR);
            wheelRotO = wheelRot;
            wheelRot += (float) (moved / 0.5 * (180.0 / Math.PI));
            if (Math.abs(wheelRot) > 3600f) {
                wheelRot %= 360f;
                wheelRotO = wheelRot;
            }
            return;
        }
        tickServer();
    }

    private void tickServer() {
        double fwd = 0, left = 0;
        boolean up = false, down = false;
        int rot = 0;
        Entity rider = getFirstPassenger();
        boolean driven = rider instanceof LivingEntity;
        if (rider instanceof LivingEntity driver) {
            fwd = driver.zza;
            left = driver.xxa;
            up = inputUp;
            down = inputDown;
            rot = inputRotate;
        } else {
            inputUp = false;
            inputDown = false;
            inputRotate = 0;
        }

        int blocks = Math.max(1, parts.size());
        double power = wheelCount >= 2 ? Mth.clamp(wheelCount * 14.0 / blocks, 0.35, 1.0) : 0.0;
        boolean carMode = power > 0;

        // rotation: arrow keys, plus car-like steering (A/D) for wheeled vehicles
        double yawRad = Math.toRadians(getYRot());
        double fx = -Math.sin(yawRad), fz = Math.cos(yawRad);
        float yawDelta = rot * 3.0f;
        steer += ((carMode ? left : 0.0) - steer) * 0.3;
        if (Math.abs(steer) < 0.01) steer = 0;
        if (carMode && steer != 0) {
            double fSpeed = velX * fx + velZ * fz;
            double factor = Mth.clamp(Math.abs(fSpeed) / 0.08, 0.3, 1.0);
            double dir = (fSpeed < -0.01 || (Math.abs(fSpeed) <= 0.01 && fwd < 0)) ? -1.0 : 1.0;
            yawDelta += (float) (-steer * 3.5 * factor * dir);
        }
        if (yawDelta != 0) {
            setYRot(getYRot() + yawDelta);
        }

        // direction the driver wants to go, relative to the vehicle
        yawRad = Math.toRadians(getYRot());
        fx = -Math.sin(yawRad);
        fz = Math.cos(yawRad);
        double lx = Math.cos(yawRad), lz = Math.sin(yawRad);
        double wx = fx * fwd + (carMode ? 0.0 : lx * left);
        double wz = fz * fwd + (carMode ? 0.0 : lz * left);
        double wlen = Math.hypot(wx, wz);
        if (wlen > 1.0) {
            wx /= wlen;
            wz /= wlen;
            wlen = 1.0;
        }
        boolean wish = wlen > 0.01;

        double waterDepth = getFluidHeight(FluidTags.WATER);
        boolean inWater = waterDepth > 0.0;
        boolean grounded = onGround() && !inWater;

        // ----- wheels -----
        double wheelMax = 0.0;
        if (power > 0) {
            if (grounded) wheelMax = 0.24 * power;
            else if (inWater) wheelMax = 0.09;
        }

        if (wish && wheelMax > 0) {
            double sc = wheelMax * ((fwd < 0 && left == 0) ? 0.6 : 1.0);
            double tx = wx * sc, tz = wz * sc;
            double dx = tx - velX, dz = tz - velZ;
            double d = Math.hypot(dx, dz);
            double step = 0.02 + 0.02 * power;
            if (d <= step) {
                velX = tx;
                velZ = tz;
            } else {
                velX += dx / d * step;
                velZ += dz / d * step;
            }
        } else {
            double drag = grounded ? (wheelMax > 0 ? 0.78 : 0.7) : (inWater ? 0.9 : 0.97);
            velX *= drag;
            velZ *= drag;
        }

        if (carMode && (grounded || inWater)) {
            double fs = velX * fx + velZ * fz;
            velX = fx * fs;
            velZ = fz * fs;
        }

        // ----- side thrusters (fans, propellers...) -----
        if (wish && !sideThrusters.isEmpty()) {
            double th = Math.toRadians(getYRot() - baseYaw);
            double c = Math.cos(th), s = Math.sin(th);
            double unit = Mth.clamp(0.02 / Math.sqrt(blocks / 10.0), 0.003, 0.04);
            double wnx = wx / wlen, wnz = wz / wlen;
            double ax = 0, az = 0;
            for (double[] t : sideThrusters) {
                double px = t[0] * c - t[1] * s;
                double pz = t[0] * s + t[1] * c;
                double dot = px * wnx + pz * wnz;
                if (dot > 0.3) {
                    ax += px * dot * unit;
                    az += pz * dot * unit;
                }
            }
            velX += ax;
            velZ += az;
            double cap = Math.max(wheelMax, 0.4);
            double sp = Math.hypot(velX, velZ);
            if (sp > cap) {
                velX *= cap / sp;
                velZ *= cap / sp;
            }
        }
        if (Math.abs(velX) < 0.003) velX = 0;
        if (Math.abs(velZ) < 0.003) velZ = 0;

        // ----- vertical: flight (up thrusters), floating, or gravity -----
        boolean flying = driven && thrustUp > 0;
        if (inWater && !(flying && up)) {
            // float: keep the bottom half block under water
            velY = Mth.clamp(velY * 0.6 + (waterDepth - 0.5) * 0.1, -0.2, 0.2);
        } else if (flying) {
            double target = up ? Math.min(0.3, 0.06 + thrustUp * 0.02) : (down ? -0.2 : 0.0);
            velY += (target - velY) * 0.2;
        } else {
            if (!isNoGravity()) velY -= 0.08;
            velY *= 0.98;
        }

        Vec3 before = position();
        move(MoverType.SELF, new Vec3(velX, velY, velZ));
        Vec3 after = position();
        if (horizontalCollision) {
            if (Math.abs(after.x - before.x) < Math.abs(velX) * 0.5) velX = 0;
            if (Math.abs(after.z - before.z) < Math.abs(velZ) * 0.5) velZ = 0;
        }
        if (verticalCollision) {
            if ((velY < 0 && onGround()) || velY > 0) velY = 0;
        }
        setDeltaMovement(velX, velY, velZ);

        if (getY() < level().getMinBuildHeight() - 64) {
            discard();
        }
    }

    // ---------- disassembly ----------

    public void disassemble() {
        if (!(level() instanceof ServerLevel serverLevel)) return;
        ejectPassengers();

        int quarter = Math.floorMod(Math.round((getYRot() - baseYaw) / 90.0f), 4);
        Rotation rot = switch (quarter) {
            case 1 -> Rotation.CLOCKWISE_90;
            case 2 -> Rotation.CLOCKWISE_180;
            case 3 -> Rotation.COUNTERCLOCKWISE_90;
            default -> Rotation.NONE;
        };
        BlockPos origin = new BlockPos((int) Math.round(getX()), (int) Math.round(getY()), (int) Math.round(getZ()));

        for (Part p : parts) {
            BlockPos target = origin.offset(p.offset().rotate(rot));
            BlockState placed = p.state().rotate(rot);
            BlockState existing = serverLevel.getBlockState(target);
            if (existing.isAir() || existing.canBeReplaced()) {
                serverLevel.setBlock(target, placed, Block.UPDATE_ALL);
            } else {
                Block.dropResources(placed, serverLevel, target);
            }
        }
        discard();
    }
}
