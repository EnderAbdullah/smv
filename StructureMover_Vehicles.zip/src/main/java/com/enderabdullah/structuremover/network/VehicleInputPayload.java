package com.enderabdullah.structuremover.network;

import com.enderabdullah.structuremover.StructureMoverMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Extra driver input that vanilla does not send for vehicles: up, down and rotation (-1 left, +1 right). */
public record VehicleInputPayload(boolean up, boolean down, int rotate) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<VehicleInputPayload> TYPE = new CustomPacketPayload.Type<>(
            ResourceLocation.fromNamespaceAndPath(StructureMoverMod.MOD_ID, "vehicle_input"));

    public static final StreamCodec<ByteBuf, VehicleInputPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, VehicleInputPayload::up,
            ByteBufCodecs.BOOL, VehicleInputPayload::down,
            ByteBufCodecs.VAR_INT, VehicleInputPayload::rotate,
            VehicleInputPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
