package com.enderabdullah.structuremover.client;

import com.enderabdullah.structuremover.StructureMoverMod;
import com.enderabdullah.structuremover.entity.VehicleEntity;
import com.enderabdullah.structuremover.network.VehicleInputPayload;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

/** Reads the extra driving keys and sends them to the server while the player rides a vehicle. */
@EventBusSubscriber(modid = StructureMoverMod.MOD_ID, value = Dist.CLIENT)
public class VehicleControls {
    public static final String CATEGORY = "key.categories.structuremover";
    public static final KeyMapping ROTATE_LEFT = new KeyMapping("key.structuremover.rotate_left", GLFW.GLFW_KEY_LEFT, CATEGORY);
    public static final KeyMapping ROTATE_RIGHT = new KeyMapping("key.structuremover.rotate_right", GLFW.GLFW_KEY_RIGHT, CATEGORY);

    private static boolean lastUp, lastDown;
    private static int lastRot;
    private static int ticks;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        boolean riding = player != null && player.getVehicle() instanceof VehicleEntity;

        boolean up = false, down = false;
        int rot = 0;
        if (riding && mc.screen == null) {
            up = mc.options.keyJump.isDown();
            down = mc.options.keySprint.isDown();
            rot = (ROTATE_RIGHT.isDown() ? 1 : 0) - (ROTATE_LEFT.isDown() ? 1 : 0);
        }

        boolean changed = up != lastUp || down != lastDown || rot != lastRot;
        if (riding && (changed || ++ticks % 20 == 0)) {
            PacketDistributor.sendToServer(new VehicleInputPayload(up, down, rot));
        }
        lastUp = up;
        lastDown = down;
        lastRot = rot;
    }
}
